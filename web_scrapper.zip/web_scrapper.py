import pandas as pd
from bs4 import BeautifulSoup
import requests
import csv

class Web_Scraper():
     def __init__(self):
        self.scraper()
        
     def scraper(self):
        department_name = input("Ener the name of the department to get the staff info:")
        self.url = "https://www.shepherd.edu/"+department_name+"/staff"

        try:
            self.page = requests.get(self.url)
        except:
            print("Page not found")
        self.csvname = department_name + ".csv"
        self.soup = BeautifulSoup(self.page.content, "html.parser")
        staff_data = self.soup.find_all('div', class_='staff-item')
        csv_data = []
        field_names = ["Name", "Title", "Email", "Phone", "Office", "Description"]
        for item in staff_data:
              staffinfodict = {"Name": item.find("h2").text}
              lines = item.find_all("tr")
              for line in lines:
                  th = line.find("th")
                  td = line.find("td")
                  if th is not None:
                        if td is not None:
                            if th.text == "Email":
                                  text = td.text
                                  text = text.strip()
                                  text = text[0:text.index("@")+13]
                                  staffinfodict[th.text] = text
                            else:
                                  staffinfodict[th.text] = td.text.strip()
                  elif th is None:
                        if td is not None:
                            staffinfodict["Description"] = td.text.strip()
              staffinfo = ["None","None", "None", "None", "None", "None"]
              staffinfo[0]=staffinfodict.get("Name", "not listed")
              staffinfo[1]=staffinfodict.get("Title", "not listed")
              staffinfo[2]=staffinfodict.get("Email", "not listed")
              staffinfo[3]=staffinfodict.get("Phone", "not listed")
              staffinfo[4]=staffinfodict.get("Office", "not listed")
              staffinfo[5]=staffinfodict.get("Description", "not listed")

              csv_data.append(staffinfo)
        with open(self.csvname, "w") as f:
              w = csv.writer(f)
              w.writerow(field_names)
              w.writerows(csv_data)
if __name__ == "__main__":
      ws = Web_Scraper()



     

